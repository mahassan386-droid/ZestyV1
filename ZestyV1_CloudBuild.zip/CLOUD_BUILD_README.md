# Zesty V1 — Cloud Build Package

هذا المشروع مجهز للبناء السحابي عبر GitHub Actions.

## الطريقة من الهاتف

1. أنشئ Repository جديد على GitHub باسم `ZestyV1`.
2. ارفع كل ملفات هذا المشروع إلى المستودع.
3. افتح تبويب **Actions**.
4. اختر **Build Zesty APK**.
5. اضغط **Run workflow**.
6. بعد انتهاء البناء، افتح الـworkflow ثم **Artifacts**.
7. حمّل `Zesty-debug-apk` وفك الضغط، وستجد `app-debug.apk`.
8. ثبّت الـAPK على هاتف Android.

## ملاحظات

- المشروع يستخدم Android Gradle Plugin 8.6.1 وGradle 8.10.2 وJDK 17.
- هذه نسخة Debug للتجربة وليست إصدارًا منشورًا على Google Play.
- لاحقًا يمكن إضافة توقيع Release، قاعدة بيانات، طباعة 58/80mm، المخزون والتقارير.
