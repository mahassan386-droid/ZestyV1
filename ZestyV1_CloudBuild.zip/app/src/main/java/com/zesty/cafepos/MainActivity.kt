package com.zesty.cafepos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Coffee = Color(0xFF24150F)
private val Gold = Color(0xFFC89B5A)
private val Cream = Color(0xFFF7F1E8)
private val Card = Color(0xFF3A241A)

data class Product(val name: String, val price: Double, val category: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZestyApp() }
    }
}

@Composable
fun ZestyApp() {
    val products = listOf(
        Product("إسبريسو", 50.0, "ساخنة"),
        Product("كابتشينو", 70.0, "ساخنة"),
        Product("لاتيه", 75.0, "ساخنة"),
        Product("موكا", 80.0, "ساخنة"),
        Product("آيس لاتيه", 85.0, "باردة"),
        Product("عصير برتقال", 60.0, "عصائر"),
        Product("مياه", 15.0, "أخرى"),
        Product("تشيز كيك", 90.0, "حلويات")
    )
    var selectedCategory by remember { mutableStateOf("الكل") }
    val cart = remember { mutableStateListOf<Product>() }
    val shown = if (selectedCategory == "الكل") products else products.filter { it.category == selectedCategory }
    val total = cart.sumOf { it.price }

    MaterialTheme(colorScheme = lightColorScheme(primary = Gold, background = Cream)) {
        Column(Modifier.fillMaxSize().background(Cream)) {
            Header()
            Row(Modifier.fillMaxSize().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.weight(1f)) {
                    CategoryBar(selectedCategory) { selectedCategory = it }
                    Spacer(Modifier.height(10.dp))
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(shown) { product ->
                            ProductCard(product) { cart.add(product) }
                        }
                    }
                }
                OrderPanel(cart, total, onClear = { cart.clear() }, modifier = Modifier.width(260.dp))
            }
        }
    }
}

@Composable
fun Header() {
    Row(
        Modifier.fillMaxWidth().background(Coffee).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("ZESTY", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        Text("الكاشير: المدير   •   اليوم", color = Color.White, fontSize = 13.sp)
    }
}

@Composable
fun CategoryBar(selected: String, onSelect: (String) -> Unit) {
    val cats = listOf("الكل", "ساخنة", "باردة", "عصائر", "حلويات", "أخرى")
    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        cats.forEach { cat ->
            FilterChip(
                selected = selected == cat,
                onClick = { onSelect(cat) },
                label = { Text(cat) }
            )
        }
    }
}

@Composable
fun ProductCard(product: Product, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().height(105.dp).clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Card)
    ) {
        Column(
            Modifier.fillMaxSize().padding(14.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(product.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(7.dp))
            Text("${product.price.toInt()} ج", color = Gold, fontSize = 17.sp)
        }
    }
}

@Composable
fun OrderPanel(
    cart: List<Product>,
    total: Double,
    onClear: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxHeight(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Text("الطلب الحالي", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Coffee)
            Spacer(Modifier.height(12.dp))
            if (cart.isEmpty()) {
                Text("لم يتم إضافة منتجات", color = Color.Gray)
            } else {
                cart.forEach { item ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                        Text(item.name, Modifier.weight(1f))
                        Text("${item.price.toInt()} ج")
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            HorizontalDivider()
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth()) {
                Text("الإجمالي", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                Text("${"%.2f".format(total)} ج", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Gold)
            }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = onClear, Modifier.fillMaxWidth()) { Text("مسح الطلب") }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { },
                Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Coffee)
            ) {
                Text("دفع ${"%.2f".format(total)} ج", fontSize = 18.sp)
            }
        }
    }
}
